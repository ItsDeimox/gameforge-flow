# GameForge Flow v0.8.9

Abra `START.bat` para iniciar o aplicativo em `http://localhost:8765`.

Esta versão restaura o pacote público, padroniza o botão Voltar em formato de losango, alinha a faixa ativa dos documentos e força a atualização dos arquivos visuais para evitar versões antigas em cache.

Os Saves locais continuam no navegador. Ao hospedar um Save para a equipe, os dados ficam na pasta `GameForge_Flow_Data`, fora da pasta pública do aplicativo.
